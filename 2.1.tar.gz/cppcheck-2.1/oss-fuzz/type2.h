
#pragma once

#include <cstdint>
#include <string>

std::string generateCode2(const uint8_t *data, size_t dataSize);

